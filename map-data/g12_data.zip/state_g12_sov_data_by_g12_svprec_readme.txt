Filename:	state_g12_sov_data_by_g12_svprec.dbf, state_g12_sov_data_by_g12_svprec.csv

File URL:	http://statewidedatabase.org/pub/data/G12/state/state_g12_sov_data_by_g12_svprec.zip

Dataset:	2012 General Election Precinct Data

Description:	Statewide Statement of Vote data files containing precinct level voting results for statewide races.

Unit of analysis:  SV precincts are the original voting precincts designated by the county registrar of voters.

Data source:	Statewide Database - University of California, Berkeley

Technical documentation:	http://statewidedatabase.org/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf
	
Codebook: 2012 General Election Statement of Vote County code books

The SOV data codebooks are county and election specific because the district races and 
candidates who ran in those races vary by county and election. 

The 58 Statement of Vote county codebooks can be accessed from the election's precinct data table,
http://statewidedatabase.org/d10/g12.html

To use the Statement of Vote county codebooks to determine the names of the candidates that were on a ballot in a given
precinct, retrieve the district number from the table/ file for that precinct record. The 
Assembly, Board of Equalization, Congressional and Senate district that each precinct is located in are listed in
the columns ADDIST,BEDIST CDDIST and SDDIST in the SOV data files. Some instances will be all zeros
if there were no candidates for that party in that race.

Date last modified:  Fri,13/Nov/2020

Previous versions:	Wed, 28 May 2014;	Tue, 04 Mar 2014 
	Fri, 09 Nov 2018  


County records unavailable at time of file creation:	none

Errata 1:	There is a discrepancy in the total between the sv and sr precinct files for one county
073 - San Diego sv file has 1 more vote cast than than the sr file
