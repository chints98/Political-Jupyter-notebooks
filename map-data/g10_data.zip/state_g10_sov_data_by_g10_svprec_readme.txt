Filename: state_g10_sov_data_by_g10_svprec.zip

File URL: http://swdb.berkeley.edu/pub/data/G10/state/state_g10_sov_data_by_g10_svprec.zip

Dataset: 2010 General Election Precinct Data

Description: This file contains statewide precinct level voting results. SV precincts are derived from Original Voting Precincts (designated by County Registrar)
Please refer to technical documentation for further information,
http://swdb.berkeley.edu/d10/Creating%20CA%20Official%20Redistricting%20Database.pdf

Variable codebook,
http://swdb.berkeley.edu/info/metadata/SOR_codebook.html 

Date last modified: 3/3/2011

County records not available or unavailable at time of file creation*: None